import json
import sys
import urllib.parse
import urllib.request

import xbmc
import xbmcgui
import xbmcplugin

HANDLE = int(sys.argv[1])
BASE_ARGS = sys.argv[0]
UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36"

SITES = [
    ("Chaturbate", "https://duckurbate.xyz"),
    ("Stripchat", "https://strip.duckurbate.xyz"),
    ("BongaCams", "https://bonga.duckurbate.xyz"),
    ("CAM4", "https://cam4.duckurbate.xyz"),
]
TARGETS = ["girls", "guys", "trans", "couples"]


def fetch(url):
    req = urllib.request.Request(url, headers={"User-Agent": UA, "Accept": "application/json"})
    try:
        with urllib.request.urlopen(req, timeout=15) as r:
            return json.loads(r.read().decode("utf-8", "replace"))
    except Exception as e:
        xbmc.log("duckurbate fetch failed: %s %s" % (url, e), xbmc.LOGERROR)
        return None


def url_for(**kw):
    return BASE_ARGS + "?" + urllib.parse.urlencode(kw)


def add_dir(label, art, **kw):
    li = xbmcgui.ListItem(label=label)
    if art:
        li.setArt({"thumb": art, "poster": art})
    xbmcplugin.addDirectoryItem(HANDLE, url_for(**kw), li, True)


def list_sites():
    for name, base in SITES:
        add_dir(name, None, mode="targets", base=base)
    xbmcplugin.endOfDirectory(HANDLE)


def list_targets(base):
    for t in TARGETS:
        add_dir(t.capitalize(), None, mode="catalogs", base=base, target=t)
    xbmcplugin.endOfDirectory(HANDLE)


def list_catalogs(base, target):
    man = fetch("%s/%s/manifest.json" % (base, target)) or {}
    for cat in man.get("catalogs", []):
        if cat.get("id", "").endswith(".favorites"):
            continue
        add_dir("%s  [%s]" % (cat.get("name", cat["id"]), target), None,
                mode="metas", base=base, target=target,
                ctype=urllib.parse.quote(cat["type"], safe=""), cid=cat["id"])
    xbmcplugin.endOfDirectory(HANDLE)


def list_metas(base, target, ctype, cid, skip=0):
    data = fetch("%s/%s/catalog/%s/%s.json?skip=%d" % (base, target, ctype, cid, int(skip))) or {}
    metas = data.get("metas") or []
    for m in metas:
        mid = m.get("id")
        if not mid:
            continue
        label = m.get("name") or mid
        art = m.get("poster") or m.get("background")
        li = xbmcgui.ListItem(label=label)
        if art:
            li.setArt({"thumb": art, "poster": art, "fanart": art})
        li.setInfo("video", {"title": label, "plot": m.get("description") or ""})
        xbmcplugin.addDirectoryItem(
            HANDLE, url_for(mode="streams", base=base, target=target, ctype=ctype, mid=urllib.parse.quote(mid, safe="")), li, True)
    if len(metas) >= 60:
        add_dir("Next page >>", None, mode="metas", base=base, target=target, ctype=ctype, cid=cid, skip=int(skip) + len(metas))
    xbmcplugin.endOfDirectory(HANDLE)


def list_streams(base, target, ctype, mid):
    data = fetch("%s/%s/stream/%s/%s.json" % (base, target, ctype, mid)) or {}
    streams = data.get("streams") or []
    played = False
    for s in streams:
        u = s.get("url")
        if not u:
            continue
        li = xbmcgui.ListItem(label=s.get("title") or s.get("name") or "Live")
        li.setMimeType("application/vnd.apple.mpegurl" if ".m3u8" in u else "video/mp4")
        if not played:
            played = True
            li.setPath(u)
            xbmcplugin.setResolvedUrl(HANDLE, True, li)
            return
    if not played:
        exts = [s.get("externalUrl") for s in streams if s.get("externalUrl")]
        if exts:
            xbmcgui.Dialog().ok("Duckurbate", "No playable stream.\n\nOpen in browser:\n" + "\n".join(dict.fromkeys(exts)))
        else:
            xbmcgui.Dialog().notification("Duckurbate", "Room offline - try another", xbmcgui.NOTIFICATION_INFO, 4000)
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False)


params = dict(urllib.parse.parse_qsl(sys.argv[2].lstrip("?")))
mode = params.get("mode")

if mode == "targets":
    list_targets(params["base"])
elif mode == "catalogs":
    list_catalogs(params["base"], params["target"])
elif mode == "metas":
    list_metas(params["base"], params["target"], params["ctype"], params["cid"], params.get("skip", 0))
elif mode == "streams":
    list_streams(params["base"], params["target"], params["ctype"], params["mid"])
else:
    list_sites()
